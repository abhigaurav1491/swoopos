import React from 'react';
import {ScrollView, StyleSheet, Text, View,Image , ImageBackground ,Button, TouchableOpacity,  List, ListItem} from 'react-native';



import { CheckBox } from 'react-native';
import { Ionicons, FontAwesome , MaterialCommunityIcons,MaterialIcons} from '@expo/vector-icons';



export default class Header extends React.Component {  

  render() {
    return (
      
       <View style={styles.topheader}>
               
                         <View style={styles.tph_one}>
                   
                          <TouchableOpacity 
                          style={[styles.colrfff , styles.mrgtop18, styles.mrglft7 ]}
                          onPress={() => this.props.navigation.openDrawer()}
                          >
                            <FontAwesome name="navicon" size={26} color='#fff'  />
                          </TouchableOpacity>

                          </View>

                           <View style={styles.tph_two}>
                   
                          <Image source={require('../../assets/images/logo.png')} style={[styles.imgcompr,styles.mrgtop15 , styles.mrglft3 ]}
                               />
                             <Text style={[styles.logotxt,styles.mrgtop15 , styles.mrglft3, ]}>Swoopos</Text>

                         </View>
               
                         
               
                          <View style={styles.tph_three}>
                     
                    
                                <Text style={[styles.colrfff , styles.mrgtop15 ]}>
                               <Ionicons name="ios-notifications" size={32}  />
                                </Text>


                           </View>

                            <View style={styles.tph_four}>
                     
                             <Text style={[styles.colrfff , styles.mrgtop15 ]}>
                               <Ionicons name="ios-cart" size={32}  />
                             </Text>

                           </View>

                          <View style={styles.tph_five}>
                   
                            <Text style={[styles.colrfff , styles.mrgtop15 ]}>
                               <MaterialCommunityIcons name="filter-variant" size={32}  />

                             </Text>

                           </View>


           </View>
    );
  }
}

const styles = StyleSheet.create({
  topheader:{width:'100%',backgroundColor: '#5bb8ce', height:80,flexDirection: 'row', alignItems: 'center',  },
  tph_one:{width:'10%',backgroundColor: 'transparent',},
  tph_two:{width:'50%',flexDirection: 'row',},
  tph_three:{width:'13%',},
  tph_four:{width:'13%',},
  tph_five:{width:'13%',},
  colrfff:{color:'#fff'},
  colrfff:{color:'white',},
  color000:{color:'#000',},
  logotxt:{color:'white',fontWeight:'normal',fontSize:20,},
  colororng:{color:'#d73f66'},
  colorblue:{color:'#5bb8ce',},
  imgcompr:{width:30, height:30,},
  imgcom25:{width:25, height:25,},
  mrglft3:{marginLeft:3,},
  mrglft7:{marginLeft:7,},
  mrgtop15:{marginTop:15,},
  mrgtop5:{marginTop:5,},
  mrgtop18:{marginTop:18,},
  fontsize14:{fontSize:18,},
  width100:{width:'100%',},
  width90:{width:'90%',},
  width85:{width:'85%',},
  width88:{width:'88%',},
  width10:{width:'10%',},
  width12:{width:'12%',},
});