import BodyContent from './BodyContent';
import Footer from './Footer';
import Header from './Header';
import InputText from './InputText';

export {
  Kaede,
  Hoshi,
  Header,
  InputText,
};
